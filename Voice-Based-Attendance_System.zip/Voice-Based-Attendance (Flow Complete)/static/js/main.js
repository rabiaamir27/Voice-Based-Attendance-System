let mediaRecorder;
let recordedChunks = [];
let currentStudent = null;

document.addEventListener("DOMContentLoaded", () => {
  const modalEl = document.getElementById("voiceModal");
  if (!modalEl) return;

  const voiceModal = new bootstrap.Modal(modalEl);
  const startBtn = document.getElementById("startRecording");
  const stopBtn = document.getElementById("stopRecording");
  const submitBtn = document.getElementById("submitVoice");
  const audioInput = document.getElementById("audioFileInput");
  const previewAudio = document.getElementById("previewAudio");
  const statusEl = document.getElementById("voiceStatus");

  document.querySelectorAll(".btn-record").forEach((btn) => {
    btn.addEventListener("click", () => {
      // Check if button is disabled (attendance already marked or locked)
      if (btn.disabled) {
        return;
      }
      currentStudent = {
        courseId: btn.getAttribute("data-course-id"),
        studentId: btn.getAttribute("data-student-id"),
        sessionId: btn.getAttribute("data-session-id"),
      };
      resetRecording(previewAudio, audioInput, statusEl);
      voiceModal.show();
    });
  });

  if (startBtn) {
    startBtn.addEventListener("click", async () => {
      recordedChunks = [];
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        mediaRecorder.ondataavailable = (e) => {
          if (e.data.size > 0) recordedChunks.push(e.data);
        };
        mediaRecorder.onstop = () => {
          const blob = new Blob(recordedChunks, { type: "audio/webm" });
          previewAudio.src = URL.createObjectURL(blob);
          previewAudio.classList.remove("d-none");
          previewAudio.load();
        };
        mediaRecorder.start();
        startBtn.disabled = true;
        stopBtn.disabled = false;
        statusEl.textContent = "Recording...";
      } catch (err) {
        console.error(err);
        statusEl.textContent = "Microphone access denied.";
      }
    });
  }

  if (stopBtn) {
    stopBtn.addEventListener("click", () => {
      if (mediaRecorder && mediaRecorder.state !== "inactive") {
        mediaRecorder.stop();
        mediaRecorder.stream.getTracks().forEach((t) => t.stop());
        startBtn.disabled = false;
        stopBtn.disabled = true;
        statusEl.textContent = "Recording stopped.";
      }
    });
  }

  if (submitBtn) {
    submitBtn.addEventListener("click", async () => {
      if (!currentStudent) return;
      statusEl.textContent = "Submitting...";

      let blob = null;
      if (recordedChunks.length > 0) {
        blob = new Blob(recordedChunks, { type: "audio/webm" });
      }

      if (!blob) {
        statusEl.textContent = "Please record audio first.";
        return;
      }

      const formData = new FormData();
      formData.append("audio", blob, "voice.webm");
      if (currentStudent.sessionId || (window.KIOSK_CONTEXT && window.KIOSK_CONTEXT.sessionId)) {
        formData.append("session_id", currentStudent.sessionId || window.KIOSK_CONTEXT.sessionId);
      }

      let url = window.KIOSK_CONTEXT.voiceLoginUrlTemplate
        .replace("COURSE_ID", currentStudent.courseId)
        .replace("STUDENT_ID", currentStudent.studentId);
      if (currentStudent.sessionId) {
        url += `?session_id=${currentStudent.sessionId}`;
      } else if (window.KIOSK_CONTEXT && window.KIOSK_CONTEXT.sessionId) {
        url += `?session_id=${window.KIOSK_CONTEXT.sessionId}`;
      }

      try {
        const resp = await fetch(url, { method: "POST", body: formData });
        const data = await resp.json();
        
        // Hide previous messages and buttons
        const decisionMsg = document.getElementById("decisionMessage");
        const fallbackBtnContainer = document.getElementById("fallbackButtonContainer");
        const passwordBtnContainer = document.getElementById("passwordButtonContainer");
        
        if (decisionMsg) decisionMsg.classList.add("d-none");
        if (fallbackBtnContainer) fallbackBtnContainer.classList.add("d-none");
        if (passwordBtnContainer) passwordBtnContainer.classList.add("d-none");
        
        // Handle different decision types
        if (data.decision === "ACCEPT") {
          // Attendance marked successfully
          statusEl.textContent = "";
          if (decisionMsg) {
            decisionMsg.className = "mt-3 alert alert-success";
            decisionMsg.innerHTML = data.message.replace(/\n/g, "<br>");
            decisionMsg.classList.remove("d-none");
          }
          // Disable voice submission button for this student
          const recordBtn = document.querySelector(`[data-student-id="${currentStudent.studentId}"].btn-record`);
          if (recordBtn) {
            recordBtn.disabled = true;
            recordBtn.textContent = "Attendance Marked";
          }
          // Update attendance status
          updateAttendanceStatus(currentStudent.studentId, "PRESENT");
          setTimeout(() => {
            voiceModal.hide();
            window.location.reload();
          }, 2000);
        } else if (data.decision === "REJECT") {
          // Voice not recognized, no fallback
          statusEl.textContent = "";
          if (decisionMsg) {
            decisionMsg.className = "mt-3 alert alert-danger";
            decisionMsg.innerHTML = data.message.replace(/\n/g, "<br>") + "<br><small>Contact admin if this seems wrong.</small>";
            decisionMsg.classList.remove("d-none");
          }
          // Disable voice submission button for this student
          const recordBtn = document.querySelector(`[data-student-id="${currentStudent.studentId}"].btn-record`);
          if (recordBtn) {
            recordBtn.disabled = true;
            recordBtn.textContent = "Voice Rejected - Locked";
          }
          updateAttendanceStatus(currentStudent.studentId, "REJECTED");
          // Close modal and reload after timeout (like ACCEPT)
          setTimeout(() => {
            voiceModal.hide();
            window.location.reload();
          }, 1000);
            } else if (data.decision === "OFFER_FALLBACK") {
          // Show fallback request button
          statusEl.textContent = "";
          if (decisionMsg) {
            decisionMsg.className = "mt-3 alert alert-warning";
            decisionMsg.innerHTML = data.message.replace(/\n/g, "<br>");
            decisionMsg.classList.remove("d-none");
          }
          if (fallbackBtnContainer && data.show_fallback) {
            fallbackBtnContainer.classList.remove("d-none");
            const fallbackBtn = document.getElementById("requestFallbackBtn");
            if (fallbackBtn) {
              // Remove any existing event listeners by cloning
              const newBtn = fallbackBtn.cloneNode(true);
              fallbackBtn.parentNode.replaceChild(newBtn, fallbackBtn);
              newBtn.onclick = () => requestFallback(currentStudent, fallbackBtnContainer, decisionMsg);
            }
          }
          // Don't disable voice submission button yet - student can still request fallback
          updateAttendanceStatus(currentStudent.studentId, "NOT_MARKED");
        } else if (data.decision === "FORCE_FALLBACK") {
          // Fallback auto-created
          statusEl.textContent = "";
          if (decisionMsg) {
            decisionMsg.className = "mt-3 alert alert-danger";
            decisionMsg.innerHTML = data.message.replace(/\n/g, "<br>");
            decisionMsg.classList.remove("d-none");
          }
          // Disable voice submission button for this student
          const recordBtn = document.querySelector(`[data-student-id="${currentStudent.studentId}"].btn-record`);
          if (recordBtn) {
            recordBtn.disabled = true;
            recordBtn.textContent = "Awaiting Admin Review";
          }
          updateAttendanceStatus(currentStudent.studentId, "NOT_MARKED");
          setTimeout(() => {
            voiceModal.hide();
            window.location.reload();
          }, 1000);
        } else if (data.decision === "LOCKED") {
          // Already processed
          statusEl.textContent = "";
          if (decisionMsg) {
            decisionMsg.className = "mt-3 alert alert-info";
            decisionMsg.innerHTML = data.message.replace(/\n/g, "<br>");
            decisionMsg.classList.remove("d-none");
          }
          // Check if password is available
          if (data.fallback_status === "approved") {
            checkPasswordAvailability(currentStudent.studentId, currentStudent.sessionId);
          }
        } else if (data.decision === "PASSWORD_AVAILABLE") {
          // Password attendance is available
          statusEl.textContent = "";
          if (decisionMsg) {
            decisionMsg.className = "mt-3 alert alert-info";
            decisionMsg.innerHTML = data.message.replace(/\n/g, "<br>");
            decisionMsg.classList.remove("d-none");
          }
          checkPasswordAvailability(currentStudent.studentId, currentStudent.sessionId);
        } else {
          // Generic error
          statusEl.textContent = data.message || "Error submitting audio.";
        }
      } catch (err) {
        console.error(err);
        statusEl.textContent = "Error submitting audio.";
      }
    });
  }
});

function resetRecording(previewAudio, audioInput, statusEl) {
  if (previewAudio) {
    previewAudio.src = "";
    previewAudio.classList.add("d-none");
  }
  if (audioInput) {
    audioInput.value = "";
  }
  if (statusEl) {
    statusEl.textContent = "";
  }
  // Reset decision message and buttons
  const decisionMsg = document.getElementById("decisionMessage");
  const fallbackBtnContainer = document.getElementById("fallbackButtonContainer");
  const passwordBtnContainer = document.getElementById("passwordButtonContainer");
  if (decisionMsg) {
    decisionMsg.classList.add("d-none");
    decisionMsg.innerHTML = "";
  }
  if (fallbackBtnContainer) fallbackBtnContainer.classList.add("d-none");
  if (passwordBtnContainer) passwordBtnContainer.classList.add("d-none");
}

function requestFallback(currentStudent, container, decisionMsg) {
  // Build URL directly from template
  const template = window.KIOSK_CONTEXT.fallbackRequestUrlTemplate || '/fallback-request/COURSE_ID/SESSION_ID/STUDENT_ID';
  const frUrl = template
    .replace("COURSE_ID", currentStudent.courseId)
    .replace("SESSION_ID", currentStudent.sessionId)
    .replace("STUDENT_ID", currentStudent.studentId);
  
  console.log("Requesting fallback:", frUrl, "Student ID:", currentStudent.studentId);
  
  fetch(frUrl, { method: "POST" })
    .then(resp => {
      if (!resp.ok) {
        return resp.json().then(data => {
          throw new Error(data.message || `HTTP ${resp.status}`);
        });
      }
      return resp.json();
    })
    .then(data => {
      if (data.success) {
        if (decisionMsg) {
          decisionMsg.className = "mt-3 alert alert-info";
          decisionMsg.innerHTML = data.message.replace(/\n/g, "<br>");
          decisionMsg.classList.remove("d-none");
        }
        container.classList.add("d-none");
        // Disable voice submission
        const recordBtn = document.querySelector(`[data-student-id="${currentStudent.studentId}"].btn-record`);
        if (recordBtn) {
          recordBtn.disabled = true;
          recordBtn.textContent = "Fallback Requested";
        }
        setTimeout(() => window.location.reload(), 2000);
      } else {
        if (decisionMsg) {
          decisionMsg.className = "mt-3 alert alert-danger";
          decisionMsg.innerHTML = data.message || "Error requesting fallback.";
          decisionMsg.classList.remove("d-none");
        }
      }
    })
    .catch(err => {
      console.error("Fallback request error:", err);
      if (decisionMsg) {
        decisionMsg.className = "mt-3 alert alert-danger";
        decisionMsg.innerHTML = `Error requesting fallback: ${err.message || "Unknown error"}`;
        decisionMsg.classList.remove("d-none");
      }
    });
}

function checkPasswordAvailability(studentId, sessionId) {
  fetch(`/check-password-availability/${studentId}/${sessionId}`)
    .then(resp => resp.json())
    .then(data => {
      if (data.password_available) {
        // Show password option in student card
        const passwordOption = document.getElementById(`password-option-${studentId}`);
        if (passwordOption) {
          passwordOption.classList.remove("d-none");
          const link = passwordOption.querySelector(".password-attendance-link");
          if (link) {
            link.href = `/fallback-login?session_id=${sessionId}`;
          }
        }
        // Show password button in modal
        const passwordBtnContainer = document.getElementById("passwordButtonContainer");
        if (passwordBtnContainer) {
          passwordBtnContainer.classList.remove("d-none");
          const passwordBtn = document.getElementById("passwordAttendanceBtn");
          if (passwordBtn) {
            passwordBtn.href = `/fallback-login?session_id=${sessionId}`;
          }
        }
      }
    })
    .catch(err => console.error("Error checking password availability:", err));
}

function updateAttendanceStatus(studentId, status) {
  const statusEl = document.getElementById(`attendance-status-${studentId}`);
  if (statusEl) {
    if (status === "PRESENT") {
      statusEl.className = "mb-2 small text-success";
      statusEl.textContent = "Attendance status: PRESENT";
    } else if (status === "REJECTED") {
      statusEl.className = "mb-2 small text-danger";
      statusEl.textContent = "Voice rejected - Attendance locked";
    } else if (status === "NOT_MARKED") {
      statusEl.className = "mb-2 small text-warning";
      statusEl.textContent = "Attendance status: NOT MARKED";
    }
  }
}

// Check password availability on page load for each student
document.addEventListener("DOMContentLoaded", () => {
  if (window.KIOSK_CONTEXT && window.KIOSK_CONTEXT.sessionId) {
    document.querySelectorAll(".student-card").forEach(card => {
      const studentId = card.getAttribute("data-student-id");
      if (studentId) {
        checkPasswordAvailability(studentId, window.KIOSK_CONTEXT.sessionId);
        // Also check attendance status
        checkAttendanceStatus(studentId, window.KIOSK_CONTEXT.sessionId);
      }
    });
  }
  
  // Handle password attendance links
  document.querySelectorAll(".password-attendance-link").forEach(link => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const studentId = link.getAttribute("data-student-id");
      const sessionId = link.getAttribute("data-session-id");
      window.location.href = `/fallback-login?session_id=${sessionId}`;
    });
  });
});

function checkAttendanceStatus(studentId, sessionId) {
  // This would require a new endpoint or we can check via the existing attendance data
  // For now, we'll rely on the backend to tell us when attendance is marked
}

// ---------------- Registration recording ----------------
let regMediaRecorder;
let regRecordedChunks = [];
let regBlob = null;

document.addEventListener("DOMContentLoaded", () => {
  const startBtn = document.getElementById("regStartRecording");
  const stopBtn = document.getElementById("regStopRecording");
  const reRecordBtn = document.getElementById("regReRecord");
  const previewAudio = document.getElementById("regPreviewAudio");
  const statusEl = document.getElementById("regRecordStatus");
  const assignButtons = document.querySelectorAll(".assign-recording");

  if (!startBtn || !stopBtn || !previewAudio) return;

  const resetState = (msg = "") => {
    regRecordedChunks = [];
    regBlob = null;
    previewAudio.classList.add("d-none");
    previewAudio.src = "";
    startBtn.disabled = false;
    stopBtn.disabled = true;
    reRecordBtn.disabled = true;
    statusEl.textContent = msg;
  };

  startBtn.addEventListener("click", async () => {
    resetState();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      regMediaRecorder = new MediaRecorder(stream);
      regMediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) regRecordedChunks.push(e.data);
      };
      regMediaRecorder.onstop = () => {
        regBlob = new Blob(regRecordedChunks, { type: "audio/webm" });
        previewAudio.src = URL.createObjectURL(regBlob);
        previewAudio.classList.remove("d-none");
        previewAudio.load();
        reRecordBtn.disabled = false;
        startBtn.disabled = false;
        stopBtn.disabled = true;
        statusEl.textContent = "Recording ready. Assign to a sample input.";
      };
      regMediaRecorder.start();
      startBtn.disabled = true;
      stopBtn.disabled = false;
      statusEl.textContent = "Recording...";
    } catch (err) {
      console.error(err);
      statusEl.textContent = "Microphone access denied.";
    }
  });

  stopBtn.addEventListener("click", () => {
    if (regMediaRecorder && regMediaRecorder.state !== "inactive") {
      regMediaRecorder.stop();
      regMediaRecorder.stream.getTracks().forEach((t) => t.stop());
      stopBtn.disabled = true;
    }
  });

  reRecordBtn.addEventListener("click", () => {
    resetState("Ready to record again.");
  });

  assignButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const inputId = btn.getAttribute("data-input-id");
      const targetInput = document.getElementById(inputId);
      if (!regBlob) {
        statusEl.textContent = "Record audio before assigning.";
        return;
      }
      if (!targetInput) return;
      const dt = new DataTransfer();
      const file = new File([regBlob], "recording.webm", { type: regBlob.type || "audio/webm" });
      dt.items.add(file);
      targetInput.files = dt.files;
      statusEl.textContent = `Recording applied to ${targetInput.name}.`;
    });
  });
});


