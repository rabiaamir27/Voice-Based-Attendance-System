import os

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "voice_attendance_secret_key")  
    # Connect to MySQL database named 'voice_attendance'
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL",
        "mysql://root:I4m^sOOper**@localhost/voice_attendance"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024

config = Config()



