import sys
import os
import numpy as np
import torch
import torchaudio
import librosa
import subprocess
import tempfile
import shutil


def convert_to_wav_if_needed(audio_path: str) -> str:
    if audio_path.lower().endswith(".wav"):
        return audio_path

    tmp_wav = tempfile.NamedTemporaryFile(suffix=".wav", delete=False).name
    cmd = [
        "ffmpeg", "-y",
        "-i", audio_path,
        "-ar", "16000",
        "-ac", "1",
        tmp_wav
    ]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return tmp_wav

# ---------------- PATH FIX ----------------
# spoof_detection.py is in /Voice_Attendance/ml/
# AASIST3 is in /Voice_Attendance/AASIST3/

BASE_DIR = os.path.dirname(os.path.abspath(__file__))          # /Voice_Attendance/ml
PROJECT_ROOT = os.path.dirname(BASE_DIR)                       # /Voice_Attendance
AASIST_PATH = os.path.join(PROJECT_ROOT, "AASIST3")            # /Voice_Attendance/AASIST3

if AASIST_PATH not in sys.path:
    sys.path.insert(0, AASIST_PATH)

# ---------------- LOAD AASIST3 ----------------
try:
    from AASIST3.model import aasist3

    aasist_model = aasist3.from_pretrained("MTUCI/AASIST3")
    aasist_model.eval()

    AASIST_AVAILABLE = True
    print("[ANTI-SPOOF] AASIST3 loaded successfully")

except Exception as e:
    print(f"[ANTI-SPOOF] AASIST3 NOT available: {str(e)}")
    aasist_model = None
    AASIST_AVAILABLE = False


# ---------------- HEURISTIC FALLBACK ----------------
def heuristic_spoof_score(audio_path: str) -> float:
    try:
        y, sr = librosa.load(audio_path, sr=16000)
    except Exception:
        return 0.9

    if len(y) < sr * 1.0:
        return 0.8

    rms = librosa.feature.rms(y=y)[0]
    energy_var = float(np.var(rms))
    silence_ratio = float(np.mean(np.abs(y) < 1e-4))
    flatness = float(np.mean(librosa.feature.spectral_flatness(y=y)))

    pitches, mags = librosa.piptrack(y=y, sr=sr)
    pitch_vals = pitches[mags > np.median(mags)]
    pitch_var = float(np.var(pitch_vals)) if len(pitch_vals) > 0 else 0

    score = 0.0
    if energy_var < 8e-4:
        score += 0.2
    if silence_ratio < 0.025:
        score += 0.15
    if flatness > 0.22:
        score += 0.35
    if pitch_var < 25:
        score += 0.3

    return min(score, 1.0)


# ---------------- AASIST INFERENCE ----------------
def aasist_infer(audio_path: str) -> float | None:
    """
    Returns spoof probability in [0,1]
    0.0 = genuine, 1.0 = spoof
    """
    if not AASIST_AVAILABLE or aasist_model is None:
        return None

    try:
        audio_path = convert_to_wav_if_needed(audio_path)
        audio, sr = torchaudio.load(audio_path)

        # Resample
        if sr != 16000:
            audio = torchaudio.transforms.Resample(sr, 16000)(audio)

        # Convert to mono
        if audio.shape[0] > 1:
            audio = torch.mean(audio, dim=0, keepdim=True)

        # Pad / truncate to 4 seconds
        target_len = 16000 * 4
        if audio.shape[1] < target_len:
            pad_len = target_len - audio.shape[1]
            audio = torch.nn.functional.pad(audio, (0, pad_len))
        else:
            audio = audio[:, :target_len]

        with torch.no_grad():
            out = aasist_model(audio)
            probs = torch.softmax(out, dim=1)

            # Class 1 = spoof
            spoof_prob = float(probs[:, 1].item())
            return max(0.0, min(1.0, spoof_prob))

    except Exception as e:
        print(f"[ANTI-SPOOF] AASIST inference error: {str(e)}")
        return None


# ---------------- MAIN ENTRY ----------------
def spoof_detect(audio_path: str) -> float:
    """
    Final spoof probability used by Flask:
    - Try AASIST3
    - If unavailable → heuristic
    """
    score = aasist_infer(audio_path)
    if score is not None:
        return float(score)

    return float(heuristic_spoof_score(audio_path))
