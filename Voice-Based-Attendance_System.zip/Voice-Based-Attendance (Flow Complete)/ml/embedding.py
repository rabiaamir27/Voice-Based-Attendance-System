import numpy as np
from resemblyzer import VoiceEncoder, preprocess_wav
import numpy as np
import os
import subprocess
import tempfile
import shutil


encoder = VoiceEncoder()   # load once globally

# Check if ffmpeg is available
def check_ffmpeg():
    """Check if ffmpeg is available in the system PATH"""
    return shutil.which("ffmpeg") is not None

if not check_ffmpeg():
    print("WARNING: FFmpeg not found in PATH. Audio conversion will fail.")

def convert_to_wav(input_path):
    # if not check_ffmpeg():
    #     raise RuntimeError("FFmpeg is not installed or not available in PATH. Please install FFmpeg to process audio files.")
    
    wav_path = input_path + ".wav"
    cmd = [
        "ffmpeg", "-y",
        "-i", input_path,
        "-ar", "16000",
        "-ac", "1",
        wav_path
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    
    if result.returncode != 0:
        error_detail = result.stderr.split('\n')[-5:] if result.stderr else "Unknown error"
        raise RuntimeError(f"FFmpeg conversion failed (return code {result.returncode}): {error_detail}")
    
    if not os.path.exists(wav_path):
        raise FileNotFoundError(f"Converted WAV file not created: {wav_path}")
    
    if os.path.getsize(wav_path) == 0:
        raise ValueError(f"Converted WAV file is empty: {wav_path}")
    
    return wav_path


def extract_embedding(audio_path: str) -> np.ndarray:
    if not os.path.exists(audio_path):
        raise FileNotFoundError(f"Audio file not found: {audio_path}")
    
    if os.path.getsize(audio_path) == 0:
        raise ValueError(f"Audio file is empty: {audio_path}")

    # Only convert if not already .wav
    ext = os.path.splitext(audio_path)[1].lower()
    if ext == ".wav":
        wav_path = audio_path
    else:
        wav_path = convert_to_wav(audio_path)
    
    try:
        wav = preprocess_wav(wav_path)
        emb = encoder.embed_utterance(wav)
        return np.array(emb, dtype=float)
    finally:
        # Clean up converted WAV file if it was created
        try:
            if wav_path != audio_path and os.path.exists(wav_path):
                os.remove(wav_path)
        except:
            pass



def compare_embeddings(stored, new) -> float:
    """
    Cosine similarity between stored and new embeddings.
    Raises ValueError if shapes differ.
    """
    a = np.array(stored, dtype=float)
    b = np.array(new, dtype=float)
    if a.shape != b.shape:
        raise ValueError(f"Embedding shape mismatch: stored={a.shape}, new={b.shape}")
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    if denom == 0:
        return 0.0
    return float(np.dot(a, b) / denom)


