-- ==========================================================
-- DATABASE FOR VOICE ATTENDANCE SYSTEM
-- ==========================================================
CREATE DATABASE IF NOT EXISTS voice_attendance;
USE voice_attendance;

-- ==========================================================
-- 1. USERS (Admin + Students)
-- Students don't register themselves. Admin creates user accounts.
-- ==========================================================
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'student') NOT NULL,
    voice_embedding TEXT NULL,            -- Final averaged embedding
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================================
-- 2. COURSES (Attendance is per-course)
-- ==========================================================
CREATE TABLE courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(100) NOT NULL,
    course_code VARCHAR(50) UNIQUE NOT NULL
);

-- ==========================================================
-- 3. STUDENTS (Extra details linked to Users)
-- ==========================================================
CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    roll_no VARCHAR(30) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    fallback_allowed BOOLEAN DEFAULT FALSE,   -- Reset after use
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- ==========================================================
-- 4. STUDENT–COURSE ENROLLMENTS
-- Kiosk page will list only students enrolled in that course
-- ==========================================================
CREATE TABLE course_enrollments (
    enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

-- ==========================================================
-- 5. ATTENDANCE SESSIONS (Admin starts session per course)
-- ==========================================================
CREATE TABLE sessions (
    session_id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    session_name VARCHAR(100),
    start_time DATETIME,
    end_time DATETIME,
    created_by INT,
    FOREIGN KEY (course_id) REFERENCES courses(course_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

-- ==========================================================
-- 6. ATTENDANCE RECORDS
-- Marked by voice or fallback
-- ==========================================================
CREATE TABLE attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    session_id INT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    status ENUM('present', 'absent', 'proxy_suspected') DEFAULT 'present',
    marked_by ENUM('system', 'admin', 'fallback') DEFAULT 'system',
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id),
    FOREIGN KEY (session_id) REFERENCES sessions(session_id)
);

-- ==========================================================
-- 7. FALLBACK LOGIN REQUESTS
-- Student failed voice → requests fallback → admin approves
-- ==========================================================
CREATE TABLE fallback_requests (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    session_id INT NOT NULL,
    reason VARCHAR(255),
    request_status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    request_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_by INT NULL,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id),
    FOREIGN KEY (session_id) REFERENCES sessions(session_id),
    FOREIGN KEY (approved_by) REFERENCES users(user_id)
);

-- ==========================================================
-- 8. SYSTEM LOGS (Spoof alerts, denials, fallback approvals)
-- ==========================================================
CREATE TABLE system_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(255),
    log_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- ==========================================================
-- 9. DEFAULT ADMIN USER
-- ==========================================================
INSERT INTO users (username, password_hash, role)
VALUES ('admin', 'scrypt:32768:8:1$myFOn9yqIfJfDLZH$8e871082f0a999c2eb9cc05f2e10c02939f4a18b9aca5585dd6eaf11f364754ca252f492e45a301861fd567c2a7229f0265db23c28e3293fb9e468b20720ef0e', 'admin');

USE voice_attendance;
UPDATE users
SET password_hash = 'scrypt:32768:8:1$myFOn9yqIfJfDLZH$8e871082f0a999c2eb9cc05f2e10c...252f492e45a301861fd567c2a7229f0265db23c28e3293fb9e468b20720ef0e'
WHERE username = 'admin';
