-- Migration: Add password_attempts table and update fallback_requests enum
-- Run this script to update the database schema for the new backend logic

USE voice_attendance;

-- 1. Update fallback_requests enum to include "used" status
ALTER TABLE fallback_requests 
MODIFY COLUMN request_status ENUM('pending', 'approved', 'rejected', 'used') DEFAULT 'pending';

-- 2. Create password_attempts table
CREATE TABLE IF NOT EXISTS password_attempts (
    attempt_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    session_id INT NOT NULL,
    attempt_number INT NOT NULL DEFAULT 1,
    success BOOLEAN NOT NULL DEFAULT FALSE,
    attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (session_id) REFERENCES sessions(session_id) ON DELETE CASCADE,
    UNIQUE KEY unique_password_attempt_session (student_id, session_id)
);

-- Index for faster lookups
CREATE INDEX idx_password_attempts_student_session ON password_attempts(student_id, session_id);

