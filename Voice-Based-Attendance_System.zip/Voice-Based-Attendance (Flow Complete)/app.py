from datetime import datetime, date
import json
import os
import tempfile

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash,
    jsonify,
)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

from config import Config

db = SQLAlchemy()


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)

    from models.users import User
    from models.students import Student
    from models.courses import Course
    from models.enrollments import CourseEnrollment
    from models.sessions import SessionModel
    from models.attendance import Attendance
    from models.fallback_requests import FallbackRequest
    from models.system_logs import SystemLog
    from models.voice_embeddings import VoiceEmbedding
    from models.password_attempts import PasswordAttempt

    from ml.embedding import extract_embedding, compare_embeddings
    from ml.spoof_detection import spoof_detect

    ALLOWED_EXTENSIONS = {"wav", "mp3", "m4a", "ogg", "webm"}

    def allowed_file(filename):
        return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

    def log_action(user_id, action, severity="info"):
        with app.app_context():
            log = SystemLog(user_id=user_id, action=action, severity=severity)
            db.session.add(log)
            db.session.commit()

    def current_admin():
        uid = session.get("user_id")
        if not uid:
            return None
        return User.query.get(uid)

    def admin_login_required(fn):
        from functools import wraps

        @wraps(fn)
        def wrapper(*args, **kwargs):
            user = current_admin()
            if not user or user.role != "admin":
                return redirect(url_for("admin_login"))
            return fn(*args, **kwargs)

        return wrapper

    # ----------------- Admin routes -----------------

    @app.route("/admin/login", methods=["GET", "POST"])
    def admin_login():
        if request.method == "POST":
            username = request.form.get("username")
            password = request.form.get("password")
            user = User.query.filter_by(username=username, role="admin").first()
            if user and check_password_hash(user.password_hash, password):
                session["user_id"] = user.user_id
                log_action(user.user_id, "Admin login")
                return redirect(url_for("admin_dashboard"))
            flash("Invalid credentials", "danger")
        return render_template("admin_login.html")

    @app.route("/admin/dashboard")
    @admin_login_required
    def admin_dashboard():
        courses = Course.query.all()
        pending_fallbacks = FallbackRequest.query.filter_by(request_status="pending").count()
        return render_template(
            "admin_dashboard.html",
            courses=courses,
            pending_fallbacks=pending_fallbacks,
        )

    @app.route("/admin/attendance")
    @admin_login_required
    def admin_attendance_redirect():
        return redirect(url_for("admin_courses"))

    @app.route("/admin/courses")
    @admin_login_required
    def admin_courses():
        courses = []
        total_courses = 0
        try:
            courses = Course.query.all()
            total_courses = len(courses) if courses else 0
        except Exception as e:
            try:
                app.logger.error(f"Error in admin_courses: {str(e)}", exc_info=True)
            except:
                pass
            flash(f"Error loading courses: {str(e)}", "danger")
        return render_template("courses.html", courses=courses, total_courses=total_courses)

    @app.route("/admin/courses/<int:course_id>")
    @admin_login_required
    def admin_course_detail(course_id):
        course = None
        sessions = []
        enrollments = []
        active_session = None

        try:
            course = Course.query.get_or_404(course_id)

            sessions = (
                SessionModel.query.filter_by(course_id=course_id)
                .order_by(SessionModel.start_time.desc())
                .all()
            )

            enrollments = (
                Student.query.join(CourseEnrollment, Student.student_id == CourseEnrollment.student_id)
                .filter(CourseEnrollment.course_id == course_id)
                .all()
            )

            active_session = next((s for s in sessions if s.end_time is None), None)

        except Exception as e:
            try:
                app.logger.error(f"Error in admin_course_detail: {str(e)}", exc_info=True)
            except:
                pass

            flash(f"Error loading course details: {str(e)}", "danger")

        return render_template(
            "course_detail.html",
            course=course,
            sessions=sessions,
            enrollments=enrollments,
            active_session=active_session,
        )


    @app.route("/admin/create_course", methods=["GET", "POST"])
    @admin_login_required
    def create_course():
        if request.method == "POST":
            name = request.form.get("course_name")
            code = request.form.get("course_code")
            if not name or not code:
                flash("Course name and code are required", "danger")
            else:
                course = Course(course_name=name, course_code=code)
                db.session.add(course)
                db.session.commit()
                log_action(current_admin().user_id, f"Created course {code}")
                flash("Course created", "success")
                return redirect(url_for("admin_courses"))
        return render_template("create_course.html")

    @app.route("/admin/register_student", methods=["GET", "POST"])
    @admin_login_required
    def register_student():
        courses = Course.query.all()
        
        
        if request.method == "POST":
            username = request.form.get("username")
            password = request.form.get("password")
            roll_no = request.form.get("roll_no")
            name = request.form.get("name")
            course_ids = request.form.getlist("courses")
            print(f"DEBUG: Received course_ids: {course_ids}")

            if not all([username, password, roll_no, name]):
                flash("All fields are required", "danger")
                return render_template("register_student.html", courses=courses)
            
            # Validate that at least one course is selected
            if not course_ids or all(not cid or not cid.strip() for cid in course_ids):
                flash("Please select at least one course for enrollment", "danger")
                return render_template("register_student.html", courses=courses)

            # Check if username already exists
            existing_user = User.query.filter_by(username=username).first()
            existing_student = None
            is_existing_student = False  # Initialize flag
            
            if existing_user:
                # Check if there's an existing student record
                existing_student = Student.query.filter_by(user_id=existing_user.user_id).first()
                
                if existing_student:
                    # Student already exists - just add to new courses
                    is_existing_student = True
                    # Check if already enrolled in any of the requested courses
                    existing_enrollments = CourseEnrollment.query.filter_by(
                        student_id=existing_student.student_id
                    ).filter(CourseEnrollment.course_id.in_([int(cid) for cid in course_ids if cid])).all()
                    
                    already_enrolled = [e.course_id for e in existing_enrollments]
                    new_courses = [int(cid) for cid in course_ids if cid and int(cid) not in already_enrolled]
                    
                    if not new_courses:
                        flash(f"Student is already enrolled in all selected courses", "info")
                        return render_template("register_student.html", courses=courses)
                    
                    # Add enrollments to new courses (will be added later in enrollment loop)
                    # Update password if provided
                    if password:
                        existing_user.password_hash = generate_password_hash(password)
                    
                    # Update name if different
                    if existing_student.name != name:
                        existing_student.name = name
                    
                    # Use existing student for voice embedding processing
                    student = existing_student
                    user = existing_user
                    db.session.flush()
                else:
                    # Orphaned user (no student record) - delete it and create new
                    db.session.delete(existing_user)
                    db.session.flush()
                    existing_user = None
            
            # Create new user and student if they don't exist
            if not existing_user:
                password_hash = generate_password_hash(password)
                user = User(username=username, password_hash=password_hash, role="student")
                db.session.add(user)
                db.session.flush()

                student = Student(user_id=user.user_id, roll_no=roll_no, name=name)
                db.session.add(student)
                db.session.flush()
            # Note: Enrollments will be added later in the code (after voice processing)

            # voice sample files
            files = [
                request.files.get("voice_sample_1"),
                request.files.get("voice_sample_2"),
                request.files.get("voice_sample_3"),
            ]
            
            
            embeddings = []
            tmp_files = []  # Track temp files for cleanup
            files_processed = 0
            files_failed = 0
            
            try:
                for idx, f in enumerate(files, 1):
                    if not f:
                        print(f"Sample {idx}: No file provided")
                        continue
                    
                    # Check if file has content - try multiple ways to check
                    content_length = getattr(f, 'content_length', None)
                    filename = getattr(f, 'filename', '')
                    
                    # Check if file is actually provided (not just empty FileStorage)
                    if not filename and (content_length is None or content_length == 0):
                        # Try to read a byte to see if there's content
                        try:
                            f.seek(0)
                            first_byte = f.read(1)
                            if not first_byte:
                                print(f"Sample {idx}: File appears to be empty")
                                continue
                            f.seek(0)  # Reset for saving
                        except:
                            print(f"Sample {idx}: Could not read file")
                            continue
                    
                    files_processed += 1
                    print(f"Sample {idx}: Processing file - filename: {filename or 'No filename'}, content_length: {content_length}")
                    
                    # Determine file extension
                    ext = '.wav'  # default
                    if f.filename:
                        if not allowed_file(f.filename):
                            continue
                        filename = secure_filename(f.filename)
                        ext = os.path.splitext(filename)[1] or '.wav'
                    else:
                        # No filename, likely recorded audio - default to webm
                        ext = '.webm'
                    
                    # Create temp file
                    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=ext)
                    tmp_files.append(tmp.name)
                    
                    try:
                        f.save(tmp.name)
                        # Verify file was saved and has content
                        if not os.path.exists(tmp.name):
                            print(f"Failed to save file for sample {idx}")
                            flash(f"Failed to save file for sample {idx}", "warning")
                            continue
                            
                        file_size = os.path.getsize(tmp.name)
                        if file_size == 0:
                            flash(f"File for sample {idx} is empty", "warning")
                            continue
                        
                        print(f"Processing sample {idx}: {tmp.name}, size: {file_size} bytes")

                        # Extract embedding
                        try:
                            emb = extract_embedding(tmp.name)
                            if emb is not None and hasattr(emb, 'tolist'):
                                embeddings.append(emb.tolist())
                                print(f"✓ Successfully extracted embedding from sample {idx}")
                            else:
                                flash(f"Failed to extract embedding from sample {idx}: invalid result", "warning")
                                print(f"✗ Failed to extract embedding from sample {idx}: invalid result")
                        except FileNotFoundError as e:
                            error_msg = f"Sample {idx}: Audio file not found - {str(e)}"
                            flash(error_msg, "warning")
                            print(f"✗ {error_msg}")
                            try:
                                app.logger.error(error_msg, exc_info=True)
                            except:
                                pass
                        except ValueError as e:
                            error_msg = f"Sample {idx}: {str(e)}"
                            flash(error_msg, "warning")
                            print(f"✗ {error_msg}")
                            try:
                                app.logger.error(error_msg, exc_info=True)
                            except:
                                pass
                        except RuntimeError as e:
                            # FFmpeg conversion error
                            files_failed += 1
                            error_msg = f"Sample {idx}: Audio conversion failed - {str(e)}"
                            flash(error_msg, "warning")
                            print(f"✗ {error_msg}")
                            print("Note: Make sure FFmpeg is installed and available in PATH")
                            import traceback
                            print(traceback.format_exc())
                            try:
                                app.logger.error(error_msg, exc_info=True)
                            except:
                                pass
                        except Exception as e:
                            files_failed += 1
                            error_msg = f"Sample {idx}: Error extracting embedding - {str(e)}"
                            flash(error_msg, "warning")
                            print(f"✗ {error_msg}")
                            import traceback
                            print(traceback.format_exc())
                            try:
                                app.logger.error(error_msg, exc_info=True)
                            except:
                                pass
                    except Exception as e:
                        error_msg = f"Error saving file for sample {idx}: {str(e)}"
                        flash(error_msg, "warning")
                        print(f"✗ {error_msg}")
                        try:
                            app.logger.error(error_msg, exc_info=True)
                        except:
                            pass
                        # Continue to next file
                        continue

                print(f"Summary: Files processed: {files_processed}, Files failed: {files_failed}, Embeddings extracted: {len(embeddings)}")
                
                if len(embeddings) == 0:
                    if files_processed == 0:
                        error_detail = "No files were detected. Please ensure you've selected or recorded audio files."
                        flash(error_detail, "danger")
                        print(f"ERROR: {error_detail}")
                    else:
                        error_detail = f"Failed to extract embeddings from {files_processed} file(s). "
                        error_detail += "Common issues: 1) FFmpeg not installed (check console), 2) Invalid audio format, 3) Corrupted files. "
                        error_detail += f"Check the warning messages above for specific errors."
                        flash(error_detail, "danger")
                        print(f"ERROR: {error_detail}")
                    db.session.rollback()
                    # Clean up temp files
                    for tmp_file in tmp_files:
                        try:
                            if os.path.exists(tmp_file):
                                os.remove(tmp_file)
                        except:
                            pass
                    return render_template("register_student.html", courses=courses)

                # Store each embedding separately in voice_embeddings table
                import numpy as np
                
                if len(embeddings) == 0:
                    raise ValueError("No valid embeddings extracted")
                
                # Insert each embedding as a separate row
                for emb in embeddings:
                    embedding_json = json.dumps(emb)
                    voice_emb = VoiceEmbedding(
                        student_id=student.student_id,
                        embedding_json=embedding_json
                    )
                    db.session.add(voice_emb)
                
                # Note: We no longer store averaged embedding in user.voice_embedding
                # Keeping the field for backward compatibility with existing data

                # enroll student in selected courses (only if not already enrolled)
                enrolled_courses = []
                for cid in course_ids:
                    if cid and cid.strip():  # Check if not empty string
                        try:
                            course_id_int = int(cid)
                            # Check if enrollment already exists
                            existing = CourseEnrollment.query.filter_by(
                                student_id=student.student_id, 
                                course_id=course_id_int
                            ).first()
                            if not existing:
                                enrollment = CourseEnrollment(
                                    student_id=student.student_id, 
                                    course_id=course_id_int
                                )
                                db.session.add(enrollment)
                                enrolled_courses.append(course_id_int)
                        except (ValueError, TypeError) as e:
                            print(f"Invalid course ID: {cid}, error: {e}")
                            continue

                db.session.commit()
                
                if enrolled_courses:
                    if is_existing_student:
                        flash(f"Student enrolled in {len(enrolled_courses)} additional course(s). Voice samples updated.", "success")
                    else:
                        flash(f"Student registered successfully and enrolled in {len(enrolled_courses)} course(s)", "success")
                else:
                    if is_existing_student:
                        flash("Student already enrolled in all selected courses. Voice samples updated.", "info")
                    else:
                        flash("Student registered successfully but no courses were selected for enrollment", "warning")
                
                log_action(current_admin().user_id, f"Registered student {roll_no}")
                return redirect(url_for("admin_dashboard"))
                
            except Exception as e:
                # Clean up temp files on error
                for tmp_file in tmp_files:
                    try:
                        if os.path.exists(tmp_file):
                            os.remove(tmp_file)
                    except:
                        pass
                db.session.rollback()
                try:
                    app.logger.error(f"Error in register_student: {str(e)}", exc_info=True)
                except:
                    pass
                flash(f"Error registering student: {str(e)}", "danger")
                return render_template("register_student.html", courses=courses)

        return render_template("register_student.html", courses=courses)

    @app.route("/admin/start_session/<int:course_id>", methods=["POST"])
    @admin_login_required
    def start_session(course_id):
        # close previous open sessions for this course
        open_sessions = SessionModel.query.filter_by(course_id=course_id, end_time=None).all()
        now = datetime.now()
        for s in open_sessions:
            s.end_time = now

        session_name = request.form.get("session_name") or f"Session {now.strftime('%Y-%m-%d %H:%M')}"
        s = SessionModel(
            course_id=course_id,
            session_name=session_name,
            start_time=now,
            created_by=current_admin().user_id,
        )
        db.session.add(s)
        db.session.commit()
        log_action(current_admin().user_id, f"Started session {s.session_id} for course {course_id}")
        return redirect(url_for("attendance_kiosk", course_id=course_id) + f"?session_id={s.session_id}")

    @app.route("/admin/session/<int:session_id>/end", methods=["POST"])
    @admin_login_required
    def end_session(session_id):
        s = SessionModel.query.get_or_404(session_id)
        s.end_time = datetime.now()
        db.session.commit()
        log_action(current_admin().user_id, f"Ended session {session_id}")
        flash("Session saved and ended.", "success")
        return redirect(url_for("admin_course_detail", course_id=s.course_id))

    @app.route("/admin/session/<int:session_id>/delete", methods=["POST"])
    @admin_login_required
    def delete_session(session_id):
        s = SessionModel.query.get_or_404(session_id)
        course_id = s.course_id
        
        try:
            # Delete related records (order matters due to foreign keys)
            PasswordAttempt.query.filter_by(session_id=session_id).delete(synchronize_session=False)
            Attendance.query.filter_by(session_id=session_id).delete(synchronize_session=False)
            FallbackRequest.query.filter_by(session_id=session_id).delete(synchronize_session=False)
            
            # Delete the session
            db.session.delete(s)
            db.session.commit()
            
            log_action(current_admin().user_id, f"Deleted session {session_id}")
            flash("Session and all related attendance records deleted.", "success")
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Error deleting session {session_id}: {str(e)}", exc_info=True)
            flash(f"Error deleting session: {str(e)}", "danger")
        
        return redirect(url_for("admin_course_detail", course_id=course_id))

    @app.route("/admin/courses/<int:course_id>/delete", methods=["POST"])
    @admin_login_required
    def delete_course(course_id):
        course = Course.query.get_or_404(course_id)
        # remove related records
        Attendance.query.filter_by(course_id=course_id).delete(synchronize_session=False)
        FallbackRequest.query.filter_by(course_id=course_id).delete(synchronize_session=False)
        SessionModel.query.filter_by(course_id=course_id).delete(synchronize_session=False)
        CourseEnrollment.query.filter_by(course_id=course_id).delete(synchronize_session=False)
        db.session.delete(course)
        db.session.commit()
        log_action(current_admin().user_id, f"Deleted course {course_id}")
        flash("Course and related records deleted.", "success")
        return redirect(url_for("admin_courses"))

    @app.route("/admin/course/<int:course_id>/remove_student/<int:student_id>", methods=["POST"])
    @admin_login_required
    def remove_student_from_course(course_id, student_id):
        enrollment = CourseEnrollment.query.filter_by(course_id=course_id, student_id=student_id).first()
        if enrollment:
            db.session.delete(enrollment)
        Attendance.query.filter_by(course_id=course_id, student_id=student_id).delete(synchronize_session=False)
        FallbackRequest.query.filter_by(course_id=course_id, student_id=student_id).delete(synchronize_session=False)
        db.session.commit()
        log_action(current_admin().user_id, f"Removed student {student_id} from course {course_id}")
        flash("Student removed from course.", "info")
        return redirect(url_for("admin_course_detail", course_id=course_id))

    @app.route("/admin/student/<int:student_id>/remove_all_courses", methods=["POST"])
    @admin_login_required
    def remove_student_from_all_courses(student_id):
        student = Student.query.get_or_404(student_id)
        user_id = student.user_id
        
        try:
            # Delete all related records (order matters due to foreign keys)
            PasswordAttempt.query.filter_by(student_id=student_id).delete(synchronize_session=False)
            VoiceEmbedding.query.filter_by(student_id=student_id).delete(synchronize_session=False)
            CourseEnrollment.query.filter_by(student_id=student_id).delete(synchronize_session=False)
            Attendance.query.filter_by(student_id=student_id).delete(synchronize_session=False)
            FallbackRequest.query.filter_by(student_id=student_id).delete(synchronize_session=False)
            
            # Delete system logs for this user (must be before deleting user)
            SystemLog.query.filter_by(user_id=user_id).delete(synchronize_session=False)
            
            # Delete the student record
            db.session.delete(student)
            
            # Delete the user record (must be last)
            user = User.query.get(user_id)
            if user:
                db.session.delete(user)
            
            db.session.commit()
            log_action(current_admin().user_id, f"Removed student {student_id} and user {user_id} from all courses and deleted records")
            flash("Student removed from all courses and deleted.", "info")
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Error removing student {student_id}: {str(e)}", exc_info=True)
            flash(f"Error removing student: {str(e)}", "danger")
        
        ref_course = request.form.get("course_id")
        if ref_course:
            return redirect(url_for("admin_course_detail", course_id=int(ref_course)))
        return redirect(url_for("admin_dashboard"))

    @app.route("/admin/session/<int:session_id>/attendance")
    @admin_login_required
    def view_session_attendance(session_id):
        s = SessionModel.query.get_or_404(session_id)
        results = (
            db.session.query(
                Student.roll_no,
                Student.name,
                Attendance.status,
                Attendance.marked_by,
                Attendance.date,
                Attendance.time
            )
            .join(Attendance, Student.student_id == Attendance.student_id)
            .filter(Attendance.session_id == session_id)
            .all()
        )
        # Convert to list of dicts for template access
        records = [
            {
                "roll_no": r[0],
                "name": r[1],
                "status": r[2],
                "marked_by": r[3],
                "date": r[4],
                "time": r[5],
            }
            for r in results
        ]
        return render_template("session_attendance.html", session_obj=s, records=records)

    @app.route("/admin/fallback_requests")
    @admin_login_required
    def admin_fallback_requests():
        results = (
            db.session.query(
                FallbackRequest.request_id,
                Student.roll_no,
                Student.name,
                Course.course_name,
                FallbackRequest.session_id,
                FallbackRequest.reason,
                FallbackRequest.request_time,
            )
            .join(Student, FallbackRequest.student_id == Student.student_id)
            .join(Course, FallbackRequest.course_id == Course.course_id)
            .filter(FallbackRequest.request_status == "pending")
            .all()
        )
        # Convert to list of dicts for template access
        pending = [
            {
                "request_id": r[0],
                "roll_no": r[1],
                "name": r[2],
                "course_name": r[3],
                "session_id": r[4],
                "reason": r[5],
                "request_time": r[6],
            }
            for r in results
        ]
        return render_template("admin_fallback_requests.html", pending_requests=pending)

    @app.route("/admin/approve_fallback/<int:request_id>", methods=["POST"])
    @admin_login_required
    def approve_fallback(request_id):
        req = FallbackRequest.query.get_or_404(request_id)
        
        # Check if already processed
        if req.request_status != "pending":
            flash("Fallback request already processed", "warning")
            return redirect(url_for("admin_fallback_requests"))
        
        # Check if attendance already marked
        existing_attendance = Attendance.query.filter_by(
            student_id=req.student_id,
            session_id=req.session_id
        ).first()
        if existing_attendance:
            flash("Attendance already marked for this session", "warning")
            return redirect(url_for("admin_fallback_requests"))
        
        # Approve fallback - unlocks password attendance
        req.request_status = "approved"
        req.approved_by = current_admin().user_id
        db.session.commit()
        
        log_action(current_admin().user_id, f"Approved fallback request {request_id} - Student: {req.student_id}, Session: {req.session_id}", "info")
        flash("Fallback approved. Student can now use password attendance.", "success")
        return redirect(url_for("admin_fallback_requests"))

    @app.route("/admin/reject_fallback/<int:request_id>", methods=["POST"])
    @admin_login_required
    def reject_fallback(request_id):
        req = FallbackRequest.query.get_or_404(request_id)
        
        if req.request_status != "pending":
            flash("Fallback request already processed", "warning")
            return redirect(url_for("admin_fallback_requests"))
        
        req.request_status = "rejected"
        req.approved_by = current_admin().user_id
        db.session.commit()
        log_action(current_admin().user_id, f"Rejected fallback request {request_id} - Student: {req.student_id}, Session: {req.session_id}", "info")
        flash("Fallback rejected. Attendance remains NOT_MARKED.", "info")
        return redirect(url_for("admin_fallback_requests"))

    # ----------------- Student-facing routes -----------------

    @app.route("/attendance/<int:course_id>")
    def attendance_kiosk(course_id):
        course = None
        students = []
        session_obj = None
        is_admin = False

        try:
            course = Course.query.get_or_404(course_id)
            is_admin = bool(current_admin())

            requested_session_id = request.args.get("session_id", type=int)

            # Find the requested session.
            if requested_session_id:
                session_obj = SessionModel.query.filter_by(
                    course_id=course_id,
                    session_id=requested_session_id
                ).first()

            # If not found, get active session.
            if not session_obj:
                session_obj = (
                    SessionModel.query.filter_by(course_id=course_id, end_time=None)
                    .order_by(SessionModel.start_time.desc())
                    .first()
                )

            # No active session exists
            if not session_obj:
                flash("No active session for this course. Please contact admin.", "warning")
                voice_login_base = url_for('voice_login', course_id=course_id, student_id=0).replace('/0', '/STUDENT_ID')
                fallback_base = f'/fallback-request/{course_id}/SESSION_ID/STUDENT_ID'
                return render_template(
                    "attendance_kiosk.html",
                    course=course,
                    students=[],
                    session_obj=None,
                    is_admin=is_admin,
                    voice_login_base=voice_login_base,
                    fallback_base=fallback_base,
                    student_attendance={},
                    student_fallbacks={},
                )

            # Session already ended → attendance locked
            if session_obj.end_time:
                flash("This session has ended. Attendance is locked.", "info")
                voice_login_base = url_for('voice_login', course_id=course_id, student_id=0).replace('/0', '/STUDENT_ID')
                fallback_base = f'/fallback-request/{course_id}/SESSION_ID/STUDENT_ID'
                return render_template(
                    "attendance_kiosk.html",
                    course=course,
                    students=[],
                    session_obj=session_obj,
                    is_admin=is_admin,
                    voice_login_base=voice_login_base,
                    fallback_base=fallback_base,
                    student_attendance={},
                    student_fallbacks={},
                )

            # Load enrolled students with attendance status
            students_query = (
                Student.query.join(CourseEnrollment, Student.student_id == CourseEnrollment.student_id)
                .filter(CourseEnrollment.course_id == course_id)
            )
            students = students_query.all()
            
            # Get attendance status for each student in this session
            student_attendance = {}
            if session_obj:
                attendance_records = Attendance.query.filter_by(
                    session_id=session_obj.session_id
                ).all()
                for att in attendance_records:
                    student_attendance[att.student_id] = {
                        "status": att.status,
                        "marked_by": att.marked_by
                    }
            
            # Get fallback request status for each student
            student_fallbacks = {}
            if session_obj:
                fallback_records = FallbackRequest.query.filter_by(
                    session_id=session_obj.session_id
                ).all()
                for fb in fallback_records:
                    student_fallbacks[fb.student_id] = {
                        "status": fb.request_status,
                        "reason": fb.reason
                    }

            # Build URL templates for JavaScript
            voice_login_base = url_for('voice_login', course_id=course_id, student_id=0).replace('/0', '/STUDENT_ID')
            if session_obj:
                # Build fallback URL template: /fallback-request/COURSE_ID/SESSION_ID/STUDENT_ID
                fallback_base = f'/fallback-request/{course_id}/SESSION_ID/STUDENT_ID'
            else:
                fallback_base = f'/fallback-request/{course_id}/SESSION_ID/STUDENT_ID'

        except Exception as e:
            # Log the error
            try:
                app.logger.error(f"Error in attendance_kiosk: {str(e)}", exc_info=True)
            except:
                pass

            flash(f"Error loading attendance kiosk: {str(e)}", "danger")

        # Build URL templates for JavaScript (if not already built)
        if 'voice_login_base' not in locals():
            voice_login_base = url_for('voice_login', course_id=course_id, student_id=0).replace('/0', '/STUDENT_ID')
            if session_obj:
                fallback_base = f'/fallback-request/{course_id}/SESSION_ID/STUDENT_ID'
            else:
                fallback_base = f'/fallback-request/{course_id}/SESSION_ID/STUDENT_ID'

        return render_template(
            "attendance_kiosk.html",
            course=course,
            students=students if 'students' in locals() else [],
            session_obj=session_obj if 'session_obj' in locals() else None,
            is_admin=is_admin if 'is_admin' in locals() else False,
            voice_login_base=voice_login_base if 'voice_login_base' in locals() else '',
            fallback_base=fallback_base if 'fallback_base' in locals() else '',
            student_attendance=student_attendance if 'student_attendance' in locals() else {},
            student_fallbacks=student_fallbacks if 'student_fallbacks' in locals() else {},
        )


    @app.route("/voice-login/<int:course_id>/<int:student_id>", methods=["POST"])
    def voice_login(course_id, student_id):
        student = Student.query.get_or_404(student_id)
        user = User.query.get_or_404(student.user_id)
        requested_session_id = request.form.get("session_id", type=int) or request.args.get("session_id", type=int)
        
        if requested_session_id:
            session_obj = SessionModel.query.filter_by(course_id=course_id, session_id=requested_session_id).first()
        else:
            session_obj = (
                SessionModel.query.filter_by(course_id=course_id, end_time=None)
                .order_by(SessionModel.start_time.desc())
                .first()
            )
        
        if not session_obj:
            return jsonify({"success": False, "message": "No active session"}), 400
        if session_obj.end_time:
            return jsonify({"success": False, "message": "Session already ended"}), 400

        # LOCK CHECK 1: Check if attendance already marked for this session
        existing_attendance = Attendance.query.filter_by(
            student_id=student.student_id,
            session_id=session_obj.session_id
        ).first()
        if existing_attendance:
            return jsonify({
                "success": False,
                "message": "Attendance already marked for this session",
                "decision": "LOCKED",
                "attendance_status": existing_attendance.status
            }), 400

        # LOCK CHECK 2: Check if fallback request already exists (prevents multiple submissions)
        existing_fallback = FallbackRequest.query.filter_by(
            student_id=student.student_id,
            session_id=session_obj.session_id
        ).first()
        if existing_fallback:
            if existing_fallback.request_status == "approved":
                # Password attendance is available
                return jsonify({
                    "success": False,
                    "message": "Voice submission locked. Password attendance available.",
                    "decision": "PASSWORD_AVAILABLE",
                    "fallback_status": "approved"
                }), 400
            else:
                return jsonify({
                    "success": False,
                    "message": "Fallback request already submitted. Await admin approval.",
                    "decision": "LOCKED",
                    "fallback_status": existing_fallback.request_status
                }), 400

        # LOCK CHECK 3: Check if password attempts exhausted
        password_attempts = PasswordAttempt.query.filter_by(
            student_id=student.student_id,
            session_id=session_obj.session_id
        ).order_by(PasswordAttempt.attempt_number.desc()).first()
        if password_attempts and password_attempts.attempt_number >= 3 and not password_attempts.success:
            return jsonify({
                "success": False,
                "message": "Maximum password attempts exceeded. Contact admin.",
                "decision": "LOCKED"
            }), 400

        file = request.files.get("audio")
        if not file:
            return jsonify({"success": False, "message": "No audio provided"}), 400
        
        # Robust empty-check for small / recorded audio
        try:
            file.seek(0)
            first_byte = file.read(1)
            if not first_byte:
                return jsonify({"success": False, "message": "Audio file is empty"}), 400
            file.seek(0)  # IMPORTANT: reset for saving
        except Exception:
            return jsonify({"success": False, "message": "Could not read audio file"}), 400

        # Determine file extension - handle both uploaded files and recorded audio
        ext = '.webm'  # default for recorded audio
        if file.filename:
            if not allowed_file(file.filename):
                return jsonify({"success": False, "message": "Invalid file type"}), 400
            filename = secure_filename(file.filename)
            ext = os.path.splitext(filename)[1] or '.webm'
        else:
            # No filename, likely recorded audio - check content type
            content_type = getattr(file, 'content_type', '')
            if 'webm' in content_type:
                ext = '.webm'
            elif 'wav' in content_type:
                ext = '.wav'
            else:
                ext = '.webm'  # default

        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=ext)
        try:
            file.save(tmp.name)
            # Verify file was saved
            if not os.path.exists(tmp.name) or os.path.getsize(tmp.name) == 0:
                return jsonify({"success": False, "message": "Failed to save audio file"}), 400
        except Exception as e:
            return jsonify({"success": False, "message": f"Error saving audio: {str(e)}"}), 400

        try:
            # Verify file exists and has content before processing
            if not os.path.exists(tmp.name):
                return jsonify({"success": False, "message": "Audio file not found"}), 400
            if os.path.getsize(tmp.name) == 0:
                return jsonify({"success": False, "message": "Audio file is empty"}), 400
            
            # Spoof detection
            spoof_prob = spoof_detect(tmp.name)
            spoof_status = "CLEAR" if spoof_prob < 0.3 else "SUSPICIOUS"
            
            # Extract embedding from submitted audio
            try:
                new_emb = extract_embedding(tmp.name)
                new_emb_list = new_emb.tolist()
            except Exception as e:
                error_msg = f"Error extracting embedding: {str(e)}"
                try:
                    app.logger.error(error_msg, exc_info=True)
                except:
                    pass
                return jsonify({"success": False, "message": error_msg}), 500
            
            # Fetch ALL embeddings for this student from voice_embeddings table
            stored_embeddings = VoiceEmbedding.query.filter_by(student_id=student.student_id).all()
            
            if not stored_embeddings:
                # Fallback to old user.voice_embedding for backward compatibility
                if user.voice_embedding:
                    stored_emb = json.loads(user.voice_embedding)
                    try:
                        similarity = compare_embeddings(stored_emb, new_emb_list)
                        best_similarity_score = similarity
                    except ValueError as e:
                        log_action(None, f"Embedding shape mismatch for student {student.student_id}: {str(e)}", "warning")
                        return jsonify({"success": False, "message": "Voice profile incompatible. Please re-register."}), 400
                else:
                    return jsonify({"success": False, "message": "No voice profile registered"}), 400
            else:
                # Compare against ALL stored embeddings and find maximum similarity
                similarities = []
                for stored_emb_obj in stored_embeddings:
                    try:
                        stored_emb = json.loads(stored_emb_obj.embedding_json)
                        similarity = compare_embeddings(stored_emb, new_emb_list)
                        similarities.append(similarity)
                    except ValueError as e:
                        # Skip embeddings with shape mismatch, log warning
                        log_action(None, f"Embedding shape mismatch for embedding_id {stored_emb_obj.embedding_id}: {str(e)}", "warning")
                        continue
                    except Exception as e:
                        log_action(None, f"Error comparing embedding_id {stored_emb_obj.embedding_id}: {str(e)}", "warning")
                        continue
                
                if not similarities:
                    return jsonify({"success": False, "message": "No valid voice embeddings found for comparison"}), 400
                
                best_similarity_score = max(similarities)
            
            # Decision thresholds
            threshold_accept = 0.73
            threshold_offer_fallback = 0.65
            
            # Decision logic according to specifications
            decision = None
            if spoof_status == "SUSPICIOUS":

                if best_similarity_score >= (threshold_accept + 0.05): # 0.05 is the margin of error
                    decision = "ACCEPT" 
                elif best_similarity_score >= (threshold_offer_fallback):
                    decision = "OFFER_FALLBACK"  # Good match but suspicious audio
                else:
                    decision = "FORCE_FALLBACK"  # Suspicious and low match
            else:  # CLEAR
                if best_similarity_score >= threshold_accept:
                    decision = "ACCEPT"
                elif best_similarity_score >= threshold_offer_fallback:
                    decision = "OFFER_FALLBACK"
                else:
                    decision = "REJECT"
            
            # Log decision details
            log_msg = (
                f"Voice attendance attempt - Student: {student.student_id}, Session: {session_obj.session_id}, "
                f"Best similarity: {best_similarity_score:.3f}, "
                f"Spoof status: {spoof_status}, "
                f"Decision: {decision}"
            )
            log_severity = "security" if spoof_status == "SUSPICIOUS" else "info"
            log_action(None, log_msg, log_severity)
            
            # Execute decision according to specifications
            if decision == "ACCEPT":
                # Mark attendance as PRESENT
                now = datetime.now()
                rec = Attendance(
                    student_id=student.student_id,
                    course_id=course_id,
                    session_id=session_obj.session_id,
                    date=date.today(),
                    time=now.time(),
                    status="present",
                    marked_by="system",
                )
                db.session.add(rec)
                db.session.commit()
                log_action(None, f"Attendance ACCEPTED - Student: {student.student_id}, Session: {session_obj.session_id}", "info")
                return jsonify({
                    "success": True,
                    "decision": "ACCEPT",
                    "message": "✅ Voice verified successfully.\nAttendance has been MARKED PRESENT.",
                    "attendance_status": "PRESENT",
                    "best_similarity_score": round(best_similarity_score, 3),
                    "spoof_status": spoof_status,
                    "show_fallback": False
                })
            
            elif decision == "REJECT":
                # Attendance NOT_MARKED, no fallback option
                # Create attendance record with status='absent' to lock the button permanently
                now = datetime.now()
                rec = Attendance(
                    student_id=student.student_id,
                    course_id=course_id,
                    session_id=session_obj.session_id,
                    date=date.today(),
                    time=now.time(),
                    status="absent",
                    marked_by="system",
                )
                db.session.add(rec)
                db.session.commit()
                log_action(None, f"Attendance REJECTED - Student: {student.student_id}, Session: {session_obj.session_id}", "info")
                return jsonify({
                    "success": False,
                    "decision": "REJECT",
                    "message": "❌ Voice not recognized.\nAttendance has NOT been marked.",
                    "attendance_status": "NOT_MARKED",
                    "best_similarity_score": round(best_similarity_score, 3),
                    "spoof_status": spoof_status,
                    "show_fallback": False
                })
            
            elif decision == "OFFER_FALLBACK":
                # Attendance NOT_MARKED, student can request fallback
                # DO NOT auto-create fallback - student must click button
                log_action(None, f"OFFER_FALLBACK - Student: {student.student_id}, Session: {session_obj.session_id}", "info")
                return jsonify({
                    "success": False,
                    "decision": "OFFER_FALLBACK",
                    "message": "⚠️ We could not confidently verify your voice.\nAttendance has NOT been marked.",
                    "attendance_status": "NOT_MARKED",
                    "best_similarity_score": round(best_similarity_score, 3),
                    "spoof_status": spoof_status,
                    "show_fallback": True,
                    "fallback_type": "OFFER"
                })
            
            elif decision == "FORCE_FALLBACK":
                # Attendance NOT_MARKED, auto-create fallback request
                # Create attendance record with status='absent' to lock the button permanently
                reason = f"🚨 Security risk detected (FORCED FALLBACK) - Similarity: {best_similarity_score:.3f}, Spoof: {spoof_status}"
                now = datetime.now()
                rec = Attendance(
                    student_id=student.student_id,
                    course_id=course_id,
                    session_id=session_obj.session_id,
                    date=date.today(),
                    time=now.time(),
                    status="absent",
                    marked_by="system",
                )
                db.session.add(rec)
                fr = FallbackRequest(
                    student_id=student.student_id,
                    course_id=course_id,
                    session_id=session_obj.session_id,
                    reason=reason,
                )
                db.session.add(fr)
                db.session.commit()
                log_action(None, f"FORCE_FALLBACK created - Student: {student.student_id}, Session: {session_obj.session_id}", "security")
                return jsonify({
                    "success": False,
                    "decision": "FORCE_FALLBACK",
                    "message": "🚨 Security risk detected (possible spoof or synthetic voice).\nAttendance has NOT been marked.\nAwait admin review.",
                    "attendance_status": "NOT_MARKED",
                    "best_similarity_score": round(best_similarity_score, 3),
                    "spoof_status": spoof_status,
                    "show_fallback": False,
                    "fallback_type": "FORCE",
                    "fallback_created": True
                })
        except Exception as e:
            error_msg = f"Error processing audio: {str(e)}"
            try:
                app.logger.error(error_msg, exc_info=True)
            except:
                pass
            return jsonify({"success": False, "message": error_msg}), 500
        finally:
            # Clean up temp file
            try:
                if os.path.exists(tmp.name):
                    os.remove(tmp.name)
            except:
                pass

    @app.route("/fallback-request/<int:course_id>/<int:session_id>/<int:student_id>", methods=["POST"])
    def fallback_request(course_id, session_id, student_id):
        # Validate student_id
        if student_id == 0 or student_id is None:
            return jsonify({
                "success": False,
                "message": "Invalid student ID"
            }), 400
        
        # Verify student exists
        student = Student.query.get(student_id)
        if not student:
            return jsonify({
                "success": False,
                "message": "Student not found"
            }), 404
        
        # Check if fallback already exists (lock)
        existing = FallbackRequest.query.filter_by(
            student_id=student_id,
            session_id=session_id
        ).first()
        if existing:
            return jsonify({
                "success": False,
                "message": "Fallback request already exists for this session"
            }), 400
        
        # Check if attendance already marked
        existing_attendance = Attendance.query.filter_by(
            student_id=student_id,
            session_id=session_id
        ).first()
        if existing_attendance:
            return jsonify({
                "success": False,
                "message": "Attendance already marked for this session"
            }), 400
        
        # Create student-initiated fallback request (OFFER_FALLBACK)
        reason = request.form.get("reason") or "⚠️ Could not verify confidently (STUDENT REQUESTED FALLBACK)"
        try:
            fr = FallbackRequest(
                student_id=student_id,
                course_id=course_id,
                session_id=session_id,
                reason=reason,
            )
            db.session.add(fr)
            db.session.commit()
            log_action(None, f"Student-initiated fallback request - Student: {student_id}, Session: {session_id}", "info")
            return jsonify({
                "success": True,
                "message": "🕒 Fallback request submitted. Attendance is NOT marked. Await admin approval."
            })
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Error creating fallback request: {str(e)}", exc_info=True)
            return jsonify({
                "success": False,
                "message": f"Error creating fallback request: {str(e)}"
            }), 500

    @app.route("/fallback-login", methods=["GET"])
    def fallback_login():
        return render_template("fallback_login.html")

    @app.route("/fallback-authenticate", methods=["POST"])
    def fallback_authenticate():
        roll_no = request.form.get("roll_no")
        password = request.form.get("password")
        session_id = request.form.get("session_id", type=int)

        if not roll_no or not password:
            flash("Roll number and password are required", "danger")
            return redirect(url_for("fallback_login"))

        student = Student.query.filter_by(roll_no=roll_no).first()
        if not student:
            flash("Invalid credentials", "danger")
            return redirect(url_for("fallback_login"))

        user = User.query.get(student.user_id)
        if not check_password_hash(user.password_hash, password):
            # Get session_id from approved fallback request if not provided
            if not session_id:
                approved_req = (
                    FallbackRequest.query.filter_by(student_id=student.student_id, request_status="approved")
                    .order_by(FallbackRequest.request_time.desc())
                    .first()
                )
                if approved_req:
                    session_id = approved_req.session_id
            
            # Track password attempt
            if session_id:
                # Get existing attempt record (due to unique constraint on student_id, session_id)
                existing_attempt = PasswordAttempt.query.filter_by(
                    student_id=student.student_id,
                    session_id=session_id
                ).first()
                
                attempt_number = (existing_attempt.attempt_number + 1) if existing_attempt else 1
                
                if attempt_number >= 3:
                    # Max attempts reached - update existing record
                    if existing_attempt:
                        existing_attempt.attempt_number = attempt_number
                        existing_attempt.success = False
                        existing_attempt.attempted_at = datetime.now()
                    else:
                        existing_attempt = PasswordAttempt(
                            student_id=student.student_id,
                            session_id=session_id,
                            attempt_number=attempt_number,
                            success=False
                        )
                        db.session.add(existing_attempt)
                    db.session.commit()
                    log_action(None, f"Password attempts exhausted - Student: {student.student_id}, Session: {session_id}", "security")
                    flash("🚫 Incorrect password. Attendance NOT marked. No attempts remaining.", "danger")
                else:
                    # Record failed attempt - update existing or create new
                    if existing_attempt:
                        existing_attempt.attempt_number = attempt_number
                        existing_attempt.success = False
                        existing_attempt.attempted_at = datetime.now()
                    else:
                        existing_attempt = PasswordAttempt(
                            student_id=student.student_id,
                            session_id=session_id,
                            attempt_number=attempt_number,
                            success=False
                        )
                        db.session.add(existing_attempt)
                    db.session.commit()
                    remaining = 3 - attempt_number
                    flash(f"❌ Incorrect password. Attendance NOT marked. Attempts remaining: {remaining}", "danger")
            else:
                flash("Invalid credentials", "danger")
            return redirect(url_for("fallback_login"))

        # Password is correct - find approved fallback request
        if not session_id:
            # Get the most recent approved fallback request for this student
            approved_req = (
                FallbackRequest.query.filter_by(student_id=student.student_id, request_status="approved")
                .order_by(FallbackRequest.request_time.desc())
                .first()
            )
            if approved_req:
                session_id = approved_req.session_id
        else:
            approved_req = FallbackRequest.query.filter_by(
                student_id=student.student_id,
                session_id=session_id,
                request_status="approved"
            ).first()

        if not approved_req:
            flash("No approved fallback request found.", "warning")
            return redirect(url_for("fallback_login"))
        
        if not session_id:
            session_id = approved_req.session_id

        # Check if attendance already marked
        existing_attendance = Attendance.query.filter_by(
            student_id=student.student_id,
            session_id=approved_req.session_id
        ).first()
        if existing_attendance:
            # If status is 'present', attendance already marked
            if existing_attendance.status == 'present':
                flash("Attendance already marked for this session.", "info")
                return redirect(url_for("fallback_login"))
            # If status is 'absent' (from voice rejection), allow fallback to override it
            # We'll update it to 'present' below

        # Check password attempts
        password_attempts = PasswordAttempt.query.filter_by(
            student_id=student.student_id,
            session_id=approved_req.session_id
        ).order_by(PasswordAttempt.attempt_number.desc()).first()
        
        if password_attempts and password_attempts.attempt_number >= 3 and not password_attempts.success:
            flash("Maximum password attempts exceeded. Contact admin.", "danger")
            return redirect(url_for("fallback_login"))

        # Mark attendance (create new or update existing if status is 'absent')
        try:
            now = datetime.now()
            if existing_attendance and existing_attendance.status == 'absent':
                # Update existing record from 'absent' (voice rejection) to 'present' (fallback success)
                existing_attendance.status = "present"
                existing_attendance.marked_by = "fallback"
                existing_attendance.date = date.today()
                existing_attendance.time = now.time()
                rec = existing_attendance
            else:
                # Create new attendance record
                rec = Attendance(
                    student_id=student.student_id,
                    course_id=approved_req.course_id,
                    session_id=approved_req.session_id,
                    date=date.today(),
                    time=now.time(),
                    status="present",
                    marked_by="fallback",
                )
                db.session.add(rec)
            
            # Mark fallback as used (if enum supports it)
            try:
                approved_req.request_status = "used"
            except (ValueError, TypeError) as e:
                # If "used" is not in the enum, just log it but continue
                app.logger.warning(f"Could not set fallback status to 'used': {str(e)}")
                # Keep it as "approved" but attendance is still marked
            
            # Record successful password attempt
            # Update existing attempt record or create new one
            attempt_number = (password_attempts.attempt_number + 1) if password_attempts else 1
            if password_attempts:
                # Update existing record
                password_attempts.attempt_number = attempt_number
                password_attempts.success = True
                password_attempts.attempted_at = datetime.now()
            else:
                # Create new record
                attempt = PasswordAttempt(
                    student_id=student.student_id,
                    session_id=approved_req.session_id,
                    attempt_number=attempt_number,
                    success=True
                )
                db.session.add(attempt)
            
            db.session.add(rec)
            db.session.commit()
            
            log_action(student.user_id, f"Password attendance successful - Student: {student.student_id}, Session: {approved_req.session_id}, Attempt: {attempt_number}", "info")
            
            # Success message and redirect to kiosk page
            flash("✅ Password verified. Attendance MARKED.", "success")
            return redirect(url_for("attendance_kiosk", course_id=approved_req.course_id) + f"?session_id={approved_req.session_id}")
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Error marking password attendance: {str(e)}", exc_info=True)
            flash(f"Error marking attendance: {str(e)}", "danger")
            return redirect(url_for("fallback_login"))

    @app.route("/check-password-availability/<int:student_id>/<int:session_id>", methods=["GET"])
    def check_password_availability(student_id, session_id):
        """Check if password attendance is available for student in session"""
        # Check if approved fallback exists
        approved_fallback = FallbackRequest.query.filter_by(
            student_id=student_id,
            session_id=session_id,
            request_status="approved"
        ).first()
        
        if not approved_fallback:
            return jsonify({
                "password_available": False,
                "reason": "No approved fallback request"
            })
        
        # Check if attendance already marked
        existing_attendance = Attendance.query.filter_by(
            student_id=student_id,
            session_id=session_id
        ).first()
        if existing_attendance:
            return jsonify({
                "password_available": False,
                "reason": "Attendance already marked"
            })
        
        # Check password attempts
        password_attempts = PasswordAttempt.query.filter_by(
            student_id=student_id,
            session_id=session_id
        ).order_by(PasswordAttempt.attempt_number.desc()).first()
        
        if password_attempts and password_attempts.attempt_number >= 3 and not password_attempts.success:
            return jsonify({
                "password_available": False,
                "reason": "Maximum attempts exceeded"
            })
        
        # Get attempt count
        attempt_count = password_attempts.attempt_number if password_attempts else 0
        remaining = 3 - attempt_count
        
        return jsonify({
            "password_available": True,
            "attempts_used": attempt_count,
            "attempts_remaining": remaining
        })

    @app.route("/")
    def index():
        return redirect(url_for("admin_login"))

    return app


if __name__ == "__main__":
    app = create_app()
    with app.app_context():
        db.create_all()
    app.run(debug=True)


