from app import db


class FallbackRequest(db.Model):
    __tablename__ = "fallback_requests"

    request_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("students.student_id"), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey("courses.course_id"), nullable=False)
    session_id = db.Column(db.Integer, db.ForeignKey("sessions.session_id"), nullable=False)
    reason = db.Column(db.String(255))
    request_status = db.Column(
        db.Enum("pending", "approved", "rejected", "used", name="fallback_status_enum"),
        default="pending",
        nullable=False,
    )
    request_time = db.Column(db.DateTime, server_default=db.func.current_timestamp())
    approved_by = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=True)

    student = db.relationship("Student", backref=db.backref("fallback_requests", lazy=True))
    course = db.relationship("Course", backref=db.backref("fallback_requests", lazy=True))


