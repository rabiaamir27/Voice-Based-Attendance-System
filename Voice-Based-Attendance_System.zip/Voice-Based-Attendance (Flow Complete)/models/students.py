from app import db


class Student(db.Model):
    __tablename__ = "students"

    student_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
    roll_no = db.Column(db.String(30), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    fallback_allowed = db.Column(db.Boolean, default=False)

    user = db.relationship("User", backref=db.backref("student_profile", uselist=False))


