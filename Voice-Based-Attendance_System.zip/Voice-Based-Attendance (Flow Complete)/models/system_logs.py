from app import db


class SystemLog(db.Model):
    __tablename__ = "system_logs"

    log_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=True)
    action = db.Column(db.String(255))
    log_time = db.Column(db.DateTime, server_default=db.func.current_timestamp())
    severity = db.Column(
        db.Enum("info", "warning", "security", name="log_severity_enum"),
        default="info",
        nullable=False,
    )


