from datetime import datetime

from app import db


class VoiceEmbedding(db.Model):
    __tablename__ = "voice_embeddings"

    embedding_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("students.student_id", ondelete="CASCADE"), nullable=False)
    embedding_json = db.Column(db.Text, nullable=False)  # JSON list of floats
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    student = db.relationship("Student", backref=db.backref("voice_embeddings", lazy=True, cascade="all, delete-orphan"))

