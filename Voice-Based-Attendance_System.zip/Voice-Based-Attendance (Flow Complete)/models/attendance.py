from datetime import date, time

from app import db


class Attendance(db.Model):
    __tablename__ = "attendance"

    attendance_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("students.student_id"), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey("courses.course_id"), nullable=False)
    session_id = db.Column(db.Integer, db.ForeignKey("sessions.session_id"), nullable=False)
    date = db.Column(db.Date, nullable=False, default=date.today)
    time = db.Column(db.Time, nullable=False)
    status = db.Column(
        db.Enum("present", "absent", "proxy_suspected", name="attendance_status_enum"),
        default="present",
        nullable=False,
    )
    marked_by = db.Column(
        db.Enum("system", "admin", "fallback", name="marked_by_enum"),
        default="system",
        nullable=False,
    )

    student = db.relationship("Student", backref=db.backref("attendance_records", lazy=True))
    course = db.relationship("Course", backref=db.backref("attendance_records", lazy=True))
    
    __table_args__ = (
        db.UniqueConstraint('student_id', 'session_id', name='unique_attendance_attempt'),
    )


