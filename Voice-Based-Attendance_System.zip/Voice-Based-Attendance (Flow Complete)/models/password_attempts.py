from datetime import datetime

from app import db


class PasswordAttempt(db.Model):
    __tablename__ = "password_attempts"

    attempt_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("students.student_id", ondelete="CASCADE"), nullable=False)
    session_id = db.Column(db.Integer, db.ForeignKey("sessions.session_id", ondelete="CASCADE"), nullable=False)
    attempt_number = db.Column(db.Integer, nullable=False, default=1)
    success = db.Column(db.Boolean, default=False, nullable=False)
    attempted_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    student = db.relationship("Student", backref=db.backref("password_attempts", lazy=True))
    session = db.relationship("SessionModel", backref=db.backref("password_attempts", lazy=True))

    __table_args__ = (
        db.UniqueConstraint('student_id', 'session_id', name='unique_password_attempt_session'),
    )

