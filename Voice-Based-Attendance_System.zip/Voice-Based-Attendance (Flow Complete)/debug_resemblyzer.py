# debug_resemblyzer.py

import os
import tempfile
import shutil
import subprocess
import numpy as np
from resemblyzer import VoiceEncoder, preprocess_wav

# ---------------- Initialize Encoder ----------------
encoder = VoiceEncoder()  # Load once globally

# ---------------- FFmpeg Check ----------------
def check_ffmpeg():
    """Check if ffmpeg is available in the system PATH"""
    return shutil.which("ffmpeg") is not None

if not check_ffmpeg():
    print("WARNING: FFmpeg not found in PATH. Audio conversion may fail.")

# ---------------- Convert Audio to WAV ----------------
def convert_to_wav(input_path):
    if not check_ffmpeg():
        raise RuntimeError("FFmpeg is not installed or not available in PATH.")
    
    wav_path = input_path + ".wav"
    cmd = [
        "ffmpeg", "-y",
        "-i", input_path,
        "-ar", "16000",
        "-ac", "1",
        wav_path
    ]
    print(f"Running FFmpeg: {' '.join(cmd)}")
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    
    if result.returncode != 0:
        error_detail = result.stderr.split('\n')[-5:] if result.stderr else "Unknown error"
        raise RuntimeError(f"FFmpeg conversion failed (return code {result.returncode}): {error_detail}")
    
    if not os.path.exists(wav_path):
        raise FileNotFoundError(f"Converted WAV file not created: {wav_path}")
    
    if os.path.getsize(wav_path) == 0:
        raise ValueError(f"Converted WAV file is empty: {wav_path}")
    
    print(f"✅ Converted WAV created: {wav_path} ({os.path.getsize(wav_path)} bytes)")
    return wav_path

# ---------------- Extract Embedding ----------------
def extract_embedding(audio_path):
    if not os.path.exists(audio_path):
        raise FileNotFoundError(f"Audio file not found: {audio_path}")
    
    print(f"Processing audio file: {audio_path}")
    # Convert to WAV if needed
    if not audio_path.lower().endswith(".wav"):
        audio_path = convert_to_wav(audio_path)
    
    wav = preprocess_wav(audio_path)
    print(f"WAV shape: {wav.shape}")
    
    emb = encoder.embed_utterance(wav)
    print(f"Embedding shape: {emb.shape}")
    
    return np.array(emb, dtype=float)

# ---------------- Main Debug Flow ----------------
if __name__ == "__main__":
    # Replace this path with your audio file
    audio_file_path = "E:/3rd Sem/Information Security/ESP/3.wav"  # <-- e.g., "E:/3rd Sem/Information Security/ESP/1.wav"
    
    tmp_files = []
    try:
        # Simulate temp file creation like Flask
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(audio_file_path)[1] or ".wav")
        tmp_files.append(tmp.name)
        
        # Copy original file to temp
        with open(audio_file_path, "rb") as src, open(tmp.name, "wb") as dst:
            dst.write(src.read())
        print(f"Temporary file created: {tmp.name} ({os.path.getsize(tmp.name)} bytes)")
        
        # Extract embedding
        emb = extract_embedding(tmp.name)
        print(f"✅ Successfully extracted embedding. Length: {len(emb)}")
    
    except Exception as e:
        print(f"❌ ERROR: {str(e)}")
        import traceback
        print(traceback.format_exc())
    
    finally:
        # Cleanup temp files
        for tmp_file in tmp_files:
            try:
                if os.path.exists(tmp_file):
                    os.remove(tmp_file)
                    print(f"Temporary file deleted: {tmp_file}")
            except:
                pass
