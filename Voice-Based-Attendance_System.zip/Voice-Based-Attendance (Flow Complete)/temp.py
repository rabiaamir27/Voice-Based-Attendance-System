# E:/3rd Sem/Information Security/ESP/1.wav

from resemblyzer import VoiceEncoder, preprocess_wav
encoder = VoiceEncoder()  # this must run once
wav = preprocess_wav("E:/3rd Sem/Information Security/ESP/1.wav")
emb = encoder.embed_utterance(wav)
print(emb.shape)
